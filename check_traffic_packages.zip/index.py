# -*- coding: utf8 -*-
import json
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.lighthouse.v20200324 import lighthouse_client, models
import os
import requests

# 账号鉴权
secret_id = os.environ.get('secret_id')
secret_key = os.environ.get('secret_key')

# 微信接口参数
# 根据自己申请的企业微信上接口参数调整；
corp_id = os.environ.get('corp_id')
app_secret = os.environ.get('app_secret')
agent_id = os.environ.get('agent_id')

gz = 'ap-guangzhou'
hk = 'ap-hongkong'


# 返回文件大小
def bytes_to_string(byte_count):
    suffix_index = 0
    while byte_count >= 1024:
        byte_count /= 1024
        suffix_index += 1

    return '{:.3f}{}'.format(
        byte_count, [' bytes', 'KB', 'MB', 'GB', 'TB'][suffix_index]
    )


# 查询流量
def check_traffic_packages(region):
    try:
        text = ''
        cred = credential.Credential(secret_id, secret_key)
        http_profile = HttpProfile()
        http_profile.endpoint = "lighthouse.tencentcloudapi.com"
        client_profile = ClientProfile()
        client_profile.httpProfile = http_profile
        client = lighthouse_client.LighthouseClient(cred, region, client_profile)
        req = models.DescribeInstancesTrafficPackagesRequest()
        params = {
        }
        req.from_json_string(json.dumps(params))

        resp = client.DescribeInstancesTrafficPackages(req)
        # 获取该地区实例数量
        instances_count = resp.TotalCount
        if region == 'ap-guangzhou':
            reg = '广州'
        elif region == 'ap-hongkong':
            reg = '香港'
        else:
            reg = '该'
        text += f"{reg}地区实例总数： {instances_count}\n"
        # 获取该地区实例流量包详情
        info = resp.InstanceTrafficPackageSet
        for instance in info:
            # 实例ID
            instance_id = instance.InstanceId

            # 流量包详情
            traffic_packages = instance.TrafficPackageSet
            # 实例流量包总数
            text += f"实例ID： {instance_id}(流量包总数: {len(traffic_packages)})\n"
            for tp in traffic_packages:
                # 流量包ID
                text += f'流量包ID： {tp.TrafficPackageId}\n'
                # 已使用
                text += f'流量包已使用： {bytes_to_string(tp.TrafficUsed)}\n'
                # 总量
                text += f'流量包总量： {bytes_to_string(tp.TrafficPackageTotal)}\n'
                # 剩余
                text += f'流量包剩余： {bytes_to_string(tp.TrafficPackageRemaining)}\n'
                # 超出
                text += f'流量包超出： {bytes_to_string(tp.TrafficOverflow)}\n'
                # 开始时间
                text += f'流量包开始时间： {tp.StartTime}\n'
                # 结束时间
                text += f'流量包结束时间： {tp.EndTime}\n'
                # 最后时间
                text += f'流量包到期时间： {tp.Deadline}\n'
                # 状态
                text += f'流量包状态： {tp.Status}\n\n'
        # print(text)
        return text

    except TencentCloudSDKException as err:
        print(err)


def send_message(title, content):
    url = 'https://qyapi.weixin.qq.com/cgi-bin/gettoken'
    headers = {
        'Content-Type': 'application/json',
    }
    payload = {
        'corpid': corp_id,
        'corpsecret': app_secret,
    }
    response = requests.post(url=url, headers=headers, data=json.dumps(payload), timeout=15).json()
    access_token = response["access_token"]
    html = content.replace("\n", "<br/>")
    url = f"https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={access_token}&debug=1"
    data = {
        'msgtype': 'mpnews',
        'mpnews': {
            'articles': [
                {
                    'title': f'{title}',
                    'thumb_media_id': '21REl4GOjIfXs0Uwsj7zpMmm0t1BDILuaFuT-67mrv0Gg7PN69xPl0VdXs_BtDiF7',
                    'author': '腾讯云服务器流量查询助手',
                    'content_source_url': '',
                    'content': f'{html}',
                    'digest': f'{content}'
                }
            ]
        },
        'touser': "@all",
        'agentid': int(agent_id),
        'safe': '0'
    }

    headers = {
        'Content-Type': 'application/json',
    }
    response = requests.post(url=url, headers=headers, data=json.dumps(data)).json()
    # print(response)
    if response['errcode'] == 0:
        print('推送成功！')
    else:
        print('推送失败！')


def main():
    regions = [hk, gz]
    text = ''
    for region in regions:
        text += check_traffic_packages(region)
    # print(text)
    send_message('良心云轻量服务器流量监控', text)


main()